package com.kh.practice1.run;

import com.kh.practice1.func.VariablePractice1;
import com.kh.practice1.func.VariablePractice2;
import com.kh.practice1.func.VariablePractice3;
import com.kh.practice1.func.VariablePractice4;

public class Run {

		public static void main(String[] args) {
			
			VariablePractice2 one = new VariablePractice2();
			one.inputTest2();
		
		}
}
