package com.hw1.run;

import com.hw1.model.vo.StudentMenu;

public class StudentRun {

	public static void main(String[] args) {
		
		StudentMenu sm = new StudentMenu();
		
		
		
	}

}
