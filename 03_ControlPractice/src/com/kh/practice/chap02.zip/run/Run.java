package com.kh.practice.chap02.run;

import com.kh.practice.chap02.loop.LoopPractice;

public class Run {

	public static void main(String[] args) {
		

		LoopPractice lp = new LoopPractice();
		lp.method5();		
	}
	
	
}
