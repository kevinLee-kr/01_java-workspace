package com.kh.practice.comp.run;

import com.kh.practice.comp.func.CompExample;
import com.kh.practice.comp.func.RockPaperScissors;
import com.kh.practice.comp.func.UpAndDown;

public class Run {

	public static void main(String[] args) {
		
		CompExample ce = new CompExample();
		//ce.practice4();
		
		UpAndDown uad = new UpAndDown();
		//uad.method1();
		
		RockPaperScissors rps = new RockPaperScissors();
		rps.rps();
		
		
		
		
		
		
		
	}
	
}
