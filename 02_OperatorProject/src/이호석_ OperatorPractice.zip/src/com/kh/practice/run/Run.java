package com.kh.practice.run;

import com.kh.practice.func.OperatorPractice;

public class Run {
	public static void main(String[] aregs) {
		
		OperatorPractice hh = new OperatorPractice();
		hh.Practice9();
	}
}
