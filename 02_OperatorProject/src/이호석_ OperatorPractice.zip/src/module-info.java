/**
 * 
 */
/**
 * 
 */
module OperatorPractice {
}