package co.kh.practice.run;

import co.kh.practice.array.ArrayPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayPractice ap = new ArrayPractice();
		ap.practice16();
		
	}

}
