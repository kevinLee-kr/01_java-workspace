package com.kh.practice1.run;

import com.kh.practice1.func.VariablePractice1;

public class Run {

		public static void main(String[] args) {
			
			VariablePractice1 one = new VariablePractice1();
			one.inputTest4();
		
		}
}
