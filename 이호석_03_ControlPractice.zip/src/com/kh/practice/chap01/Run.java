package com.kh.practice.chap01;

public class Run {

	public static void main(String[] args) {
		
		
		
		ControlPractice kk = new ControlPractice();
		kk.method9();
		
	}
	
	
}
